﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form esegue l'override del metodo Dispose per pulire l'elenco dei componenti.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Richiesto da Progettazione Windows Form
    Private components As System.ComponentModel.IContainer

    'NOTA: la procedura che segue è richiesta da Progettazione Windows Form
    'Può essere modificata in Progettazione Windows Form.  
    'Non modificarla nell'editor del codice.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.dgvDatabase = New System.Windows.Forms.DataGridView()
        Me.Inserisci = New System.Windows.Forms.Button()
        Me.elimina = New System.Windows.Forms.Button()
        Me.modifica = New System.Windows.Forms.Button()
        Me.dgvDatabase2 = New System.Windows.Forms.DataGridView()
        Me.a1 = New System.Windows.Forms.CheckBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        CType(Me.dgvDatabase, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgvDatabase2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'dgvDatabase
        '
        Me.dgvDatabase.AllowUserToAddRows = False
        Me.dgvDatabase.AllowUserToDeleteRows = False
        Me.dgvDatabase.AllowUserToResizeColumns = False
        Me.dgvDatabase.AllowUserToResizeRows = False
        Me.dgvDatabase.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells
        Me.dgvDatabase.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvDatabase.Location = New System.Drawing.Point(42, 39)
        Me.dgvDatabase.Name = "dgvDatabase"
        Me.dgvDatabase.ReadOnly = True
        Me.dgvDatabase.Size = New System.Drawing.Size(238, 311)
        Me.dgvDatabase.TabIndex = 0
        '
        'Inserisci
        '
        Me.Inserisci.Location = New System.Drawing.Point(309, 77)
        Me.Inserisci.Name = "Inserisci"
        Me.Inserisci.Size = New System.Drawing.Size(75, 23)
        Me.Inserisci.TabIndex = 1
        Me.Inserisci.Text = "Inserisci"
        Me.Inserisci.UseVisualStyleBackColor = True
        '
        'elimina
        '
        Me.elimina.Location = New System.Drawing.Point(309, 168)
        Me.elimina.Name = "elimina"
        Me.elimina.Size = New System.Drawing.Size(75, 23)
        Me.elimina.TabIndex = 2
        Me.elimina.Text = "Elimina"
        Me.elimina.UseVisualStyleBackColor = True
        '
        'modifica
        '
        Me.modifica.Location = New System.Drawing.Point(309, 266)
        Me.modifica.Name = "modifica"
        Me.modifica.Size = New System.Drawing.Size(75, 23)
        Me.modifica.TabIndex = 3
        Me.modifica.Text = "Modifica"
        Me.modifica.UseVisualStyleBackColor = True
        '
        'dgvDatabase2
        '
        Me.dgvDatabase2.AllowUserToAddRows = False
        Me.dgvDatabase2.AllowUserToDeleteRows = False
        Me.dgvDatabase2.AllowUserToResizeColumns = False
        Me.dgvDatabase2.AllowUserToResizeRows = False
        Me.dgvDatabase2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells
        Me.dgvDatabase2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvDatabase2.Location = New System.Drawing.Point(421, 39)
        Me.dgvDatabase2.Name = "dgvDatabase2"
        Me.dgvDatabase2.ReadOnly = True
        Me.dgvDatabase2.Size = New System.Drawing.Size(200, 311)
        Me.dgvDatabase2.TabIndex = 4
        '
        'a1
        '
        Me.a1.AutoSize = True
        Me.a1.Location = New System.Drawing.Point(309, 107)
        Me.a1.Name = "a1"
        Me.a1.Size = New System.Drawing.Size(95, 17)
        Me.a1.TabIndex = 5
        Me.a1.Text = "Inserisci Attore"
        Me.a1.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(639, 266)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 23)
        Me.Button1.TabIndex = 8
        Me.Button1.Text = "Modifica"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(639, 168)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(75, 23)
        Me.Button2.TabIndex = 7
        Me.Button2.Text = "Elimina"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(639, 77)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(75, 23)
        Me.Button3.TabIndex = 6
        Me.Button3.Text = "Inserisci"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.Location = New System.Drawing.Point(309, 371)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(101, 56)
        Me.Button4.TabIndex = 9
        Me.Button4.Text = "SHIFT SOPRA"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoSize = True
        Me.ClientSize = New System.Drawing.Size(819, 774)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.a1)
        Me.Controls.Add(Me.dgvDatabase2)
        Me.Controls.Add(Me.modifica)
        Me.Controls.Add(Me.elimina)
        Me.Controls.Add(Me.Inserisci)
        Me.Controls.Add(Me.dgvDatabase)
        Me.Name = "Form1"
        Me.Text = "Form1"
        CType(Me.dgvDatabase, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgvDatabase2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents dgvDatabase As System.Windows.Forms.DataGridView
    Friend WithEvents Inserisci As System.Windows.Forms.Button
    Friend WithEvents elimina As System.Windows.Forms.Button
    Friend WithEvents modifica As System.Windows.Forms.Button
    Friend WithEvents dgvDatabase2 As System.Windows.Forms.DataGridView
    Friend WithEvents a1 As System.Windows.Forms.CheckBox
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Button4 As System.Windows.Forms.Button

End Class
