﻿Imports System.Data.OleDb
Public Class Form1
    Dim connessione As New OleDbConnection
    Dim mCommand As New OleDbCommand
    Dim mDataReader As OleDbDataReader
    Dim strconnessione As String
    Dim sql As String
    Private Sub Form1_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
       

        inserimento(dgvDatabase)

    End Sub

    Sub inserimento(dgvDatabase As DataGridView)
        strconnessione = "Provider=Microsoft.ACE.OleDb.12.0;data source=film.mdb"
        connessione.ConnectionString = strconnessione
        connessione.Open()
        mCommand.Connection = connessione
        sql = "select * from film"
        mCommand.CommandText = sql
        mDataReader = mCommand.ExecuteReader

        dgvDatabase.Rows.Clear()
        If dgvDatabase.Columns.Count <= 0 Then
            dgvDatabase.Columns.Add("id_film", "id_film")
            dgvDatabase.Columns.Add("titolo", "titolo")
            dgvDatabase.Columns.Add("descrizione", "descrizione")

            dgvDatabase.Columns.Add("anno_uscita", "anno_uscita")

            dgvDatabase.Columns.Add("durata", "durata")
            dgvDatabase.Columns.Add("prezzo_noleggio", "prezzo_noleggio")
            dgvDatabase.Columns.Add("costo_riscatto", "costo_riscatto")


            dgvDatabase.Columns.Add("colore", "colore")

        End If
       
        Dim R As Integer
        Dim C As Integer
        R = -1
        C = 0
        Do While mDataReader.Read
            dgvDatabase.Rows.Add()
            R += 1

            dgvDatabase.Rows(R).Cells(C).Value = mDataReader("id_film")
            C += 1
            dgvDatabase.Rows(R).Cells(C).Value = mDataReader("titolo")

            C += 1
            dgvDatabase.Rows(R).Cells(C).Value = mDataReader("descrizione")

            C += 1
            dgvDatabase.Rows(R).Cells(C).Value = mDataReader("anno_uscita")

            C += 1
            dgvDatabase.Rows(R).Cells(C).Value = mDataReader("durata")

            C += 1
            dgvDatabase.Rows(R).Cells(C).Value = mDataReader("prezzo_noleggio")

            C += 1
            dgvDatabase.Rows(R).Cells(C).Value = mDataReader("costo_riscatto")
            C = 0
        Loop
        connessione.Close()

        dgvDatabase2.Rows.Clear()
        If dgvDatabase2.Columns.Count <= 0 Then
            dgvDatabase2.Columns.Add("id_attore", "id_attore")
            dgvDatabase2.Columns.Add("nome", "nome")

            dgvDatabase2.Columns.Add("colore", "colore")

        End If

        strconnessione = "Provider=Microsoft.ACE.OleDb.12.0;data source=film.mdb"
        connessione.ConnectionString = strconnessione
        connessione.Open()
        mCommand.Connection = connessione
        sql = "select * from attore"
        mCommand.CommandText = sql
        mDataReader = mCommand.ExecuteReader

        R = -1
        C = 0
        Dim x As Random = New Random

        Do While mDataReader.Read
            dgvDatabase2.Rows.Add()
            R += 1

            dgvDatabase2.Rows(R).Cells(C).Value = mDataReader("id_attore")
            C += 1
            dgvDatabase2.Rows(R).Cells(C).Value = mDataReader("nome")
            C += 1

            dgvDatabase2.Rows(R).Cells(C).Value = "rgb(" & x.Next(0, 255) & ", " & x.Next(0, 255) & ", " & x.Next(0, 255) & ")"


            C = 0

        Loop
        connessione.Close()

        dgvDatabase.Sort(dgvDatabase.Columns("id_film"), System.ComponentModel.ListSortDirection.Ascending)


    End Sub


    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Inserisci.Click
        If a1.Checked = False Then
            Dim titolo As String = InputBox("Inserisci titolo nuovo film")
            titolo = titolo.ToUpper

            sql = "INSERT INTO film(titolo, lingua) VALUES('" & titolo & "', '1');"
            commands(sql)

            inserimento(dgvDatabase)
        Else

        End If
       

    End Sub
    Sub commands(sql1 As String)
        strconnessione = "Provider=Microsoft.ACE.OleDb.12.0;data source=film.mdb"
        connessione.ConnectionString = strconnessione
        connessione.Open()
        mCommand.Connection = connessione
        sql = sql1

        mCommand.CommandText = sql
        mDataReader = mCommand.ExecuteReader
        connessione.Close()
    End Sub
    Private Sub elimina_Click(sender As System.Object, e As System.EventArgs) Handles elimina.Click
        Dim id As Integer = Val(InputBox("inserisci id da eliminare"))
        If id > 0 Then

            Do
                gatto = False

                If MsgBox("Codice film da eliminare:" & id & vbNewLine & "Titolo film da eliminare: " &
                          dgvDatabase.Rows(id - 1).Cells(1).Value & vbNewLine & "Accettare modifiche?", vbYesNo) = vbYes Then
                    gatto = True
                Else
                    gatto = False
                    Exit Do
                End If
            Loop Until gatto = True

        Else
            MsgBox("Processo annullato")
        End If
        If gatto = True Then
            sql = "DELETE FROM film WHERE id_film =" & id & ";"
            commands(sql)
            inserimento(dgvDatabase)
        Else
            MsgBox("Processo annullato")
        End If
    End Sub

    Private Sub modifica_Click(sender As System.Object, e As System.EventArgs) Handles modifica.Click

        Dim id As Integer = Val(InputBox("inserisci id del film da modificare"))
        If id > 0 Then
            Dim nomedamodificare As String
            For k = 0 To dgvDatabase.Rows.Count
                If dgvDatabase.Rows(k).Cells(0).Value = id Then
                    nomedamodificare = dgvDatabase.Rows(k).Cells(1).Value

                    Exit For

                End If
            Next
            Dim nuovotitolo As String
            Do
                gatto = False
                nuovotitolo = InputBox("inserisci nuovo titolo")
                If MsgBox("Titolo film:" & nomedamodificare & vbNewLine & "Nuovo titolo film: " & nuovotitolo & vbNewLine & "Accettare modifiche?", vbYesNo) = vbYes Then
                    gatto = True
                End If
            Loop Until gatto = True
            sql = "UPDATE film SET titolo='" & nuovotitolo & "' WHERE titolo='" & nomedamodificare & "';"

            commands(sql)
            inserimento(dgvDatabase)
        Else
            MsgBox("Processo annullato")
        End If
       


    End Sub
    Dim gatto As Boolean
    Private Sub Button3_Click(sender As System.Object, e As System.EventArgs) Handles Button3.Click

        Dim nome As String
        Dim cognome As String
        Do
            gatto = False
            nome = InputBox("Inserisci il nome del nuovo attore")
            nome = nome.ToUpper
            cognome = InputBox("Inserisci il cognome di " & nome)
            cognome = cognome.ToUpper
            If MsgBox("Nome attore: " & nome &
                      vbNewLine & "Cognome attore: " & cognome & vbNewLine & "Accettare i dati inseriti?", vbYesNo) = vbYes Then
                gatto = True
            Else
                Exit Do

            End If
        Loop Until gatto = True
        If gatto = True Then
            sql = "INSERT INTO attore(nome, cognome) VALUES('" & nome & "', '1');"
            commands(sql)

            inserimento(dgvDatabase)
        Else
            MsgBox("Processo annullato")
        End If



    End Sub

    Private Sub Button4_Click(sender As System.Object, e As System.EventArgs) Handles Button4.Click
        Dim a, b As Integer
        Dim v(0) As Integer
        Dim f As Integer = 0
        For k = 0 To dgvDatabase.Rows.Count - 1

            a = dgvDatabase.Rows(k).Cells(0).Value

            v(f) = a
            f += 1
            ReDim v(f)
            Do
                gatto = False
                If k + 1 < dgvDatabase.Rows.Count Then
                    If a + 1 = dgvDatabase.Rows(k + 1).Cells(0).Value Then 'if next one ins same as current one plus one
                        gatto = True
                    Else
                        dgvDatabase.Rows(k + 1).Cells(0).Value = a + 1
                    End If
                Else
                    If a + 1 >= dgvDatabase.Rows(k).Cells(0).Value Then 'if next one ins same as current one plus one
                        gatto = True
                    Else
                        dgvDatabase.Rows(k + 1).Cells(0).Value = a + 1
                    End If

                End If

            Loop Until gatto = True


            'u have to add backups to v(f) and do WHERE v(f) matches
            sql = "UPDATE film SET id_film='" & dgvDatabase.Rows(k).Cells(0).Value & "' WHERE id='" & v(k) & "';"

            commands(sql)
            inserimento(dgvDatabase)

            '    MsgBox(dgvDatabase.Rows(k).Cells(0).Value)
        Next




    End Sub

End Class
