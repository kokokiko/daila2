$(document).ready(function() {
    $("#demo").textillate();
});
var esegui =  $("#demo");

esegui.textillate({
        
        loop:false,
        Autostart:true,
        in:{
            effect: 'swing',
            delayScale: 1.5,
            delay: 50,
            sync: false,
            shuffle: false,
            reverse: false,
            
                }
        
    });
var api = esegui.data('textillate')
$("#demo").click(function() {
    $("#demo").textillate({     
        in:{effect: 'swing'}
     })
    
   api.start();
});




$("#ul").children(".noselect").hover(function(){

  $(this).textillate();
});























